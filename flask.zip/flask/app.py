
from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

connection = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Amrites@mysql008',
    database='restaurant_database'
)
mycursor = connection.cursor()

user_dict = {'admin': '1234'}

@app.route('/')
def home():
    username = request.args.get('username', 'Guest')
    return render_template('home.html', msg='Welcome ' + username)

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
def do_login():
    username = request.form['username']
    pwd = request.form['password']
    if username not in user_dict:
        return render_template('login.html', msg='Invalid Username')
    elif user_dict[username] != pwd:
        return render_template('login.html', msg='Invalid Password')
    else:
        return redirect(url_for('home', username=username))

@app.route('/thrissur')
def thrissur():
    veg = request.args.get('veg')
    nonveg = request.args.get('nonveg')
    
    query = "SELECT * FROM Thrissur"
    conditions = []
    if veg:
        conditions.append("veg=TRUE")
    if nonveg:
        conditions.append("veg=FALSE")
    
    if conditions:
        query += " WHERE " + " OR ".join(conditions)
    
    mycursor.execute(query)
    data = mycursor.fetchall()
    return render_template('thrissur.html', sqldata=format_boolean_values(data))

def format_boolean_values(data):
    formatted_data = []
    for row in data:
        formatted_row = list(row)
        formatted_row[5] = 'Yes' if formatted_row[5] else 'No'  
        formatted_row[6] = 'Yes' if formatted_row[6] else 'No'  
        formatted_row[7] = 'Yes' if formatted_row[7] else 'No'  
        formatted_data.append(formatted_row)
    return formatted_data


@app.route('/palakkad')
def pala():
    veg = request.args.get('veg')
    nonveg = request.args.get('nonveg')
    
    query = "SELECT * FROM palakkad"
    conditions = []
    if veg:
        conditions.append("veg=TRUE")
    if nonveg:
        conditions.append("veg=FALSE")
    
    if conditions:
        query += " WHERE " + " OR ".join(conditions)
    
    mycursor.execute(query)
    data = mycursor.fetchall()
    return render_template('palakkad.html', sqldata=format_boolean_values(data))

def format_boolean_values(data):
    formatted_data = []
    for row in data:
        formatted_row = list(row)
        formatted_row[5] = 'Yes' if formatted_row[5] else 'No'  
        formatted_row[6] = 'Yes' if formatted_row[6] else 'No'  
        formatted_row[7] = 'Yes' if formatted_row[7] else 'No'  
        formatted_data.append(formatted_row)
    return formatted_data


@app.route('/ernakulam')
def erna():
    veg = request.args.get('veg')
    nonveg = request.args.get('nonveg')
    
    query = "SELECT * FROM ernakulam"
    conditions = []
    if veg:
        conditions.append("veg=TRUE")
    if nonveg:
        conditions.append("veg=FALSE")
    
    if conditions:
        query += " WHERE " + " OR ".join(conditions)
    
    mycursor.execute(query)
    data = mycursor.fetchall()
    return render_template('ernakulam.html', sqldata=format_boolean_values(data))

def format_boolean_values(data):
    formatted_data = []
    for row in data:
        formatted_row = list(row)
        formatted_row[5] = 'Yes' if formatted_row[5] else 'No'  
        formatted_row[6] = 'Yes' if formatted_row[6] else 'No'  
        formatted_row[7] = 'Yes' if formatted_row[7] else 'No'  
        formatted_data.append(formatted_row)
    return formatted_data

if __name__ == '__main__':
    app.run(debug=True)
